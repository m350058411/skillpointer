# skillpointer
She Will Punish Them-Mod-SkillPointer,using BepInEx.
push p to add skill points.
# install
1.unzip in game home dir \SteamLibrary\steamapps\common\She Will Punish Them  
2.run game.  
3.push c open skill list.  
4.push p to add skill point.  
 
